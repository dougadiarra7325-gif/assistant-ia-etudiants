// Relais IA pour l'Assistant Étudiant IAM (projet n°11).
// Reçoit une question en GET, interroge Google Gemini (clé en variable
// d'environnement Netlify, jamais publique) et renvoie la réponse en texte.
export default async (req) => {
  const url = new URL(req.url);
  if (url.searchParams.get("token") !== process.env.IA_TOKEN) {
    return new Response("unauthorised", { status: 401 });
  }
  const q = (url.searchParams.get("q") || "").slice(0, 800);
  if (!q) return new Response("missing q", { status: 400 });
  const system = (url.searchParams.get("system") || "").slice(0, 2500);
  const prompt = (system ? system + "\n\n" : "") + "Question de l'étudiant : " + q;
  try {
    const r = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
      { method: "POST",
        headers: { "Content-Type": "application/json",
                   "x-goog-api-key": process.env.GEMINI_API_KEY },
        body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.4, maxOutputTokens: 500 } }) });
    if (!r.ok) return new Response("ai_error " + r.status, { status: 502 });
    const data = await r.json();
    const text = (data.candidates?.[0]?.content?.parts || [])
      .map((p) => p.text || "").join("").trim();
    return new Response(text || "empty",
      { headers: { "Content-Type": "text/plain; charset=utf-8" } });
  } catch (e) {
    return new Response("ai_unreachable", { status: 502 });
  }
};
export const config = { path: "/ia" };
